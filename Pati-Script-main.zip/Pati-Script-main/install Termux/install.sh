#!/data/data/com.termux/files/usr/bin/bash

# Atualiza os pacotes existentes
pkg update && pkg upgrade -y

# Instala o proot-distro
pkg install proot-distro -y

# Cria um ambiente Ubuntu
proot-distro install ubuntu

# Inicia o Ubuntu
proot-distro login ubuntu
